import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import ContactForm from './ContactForm';
import ContactSearch from './ContactSearch';
import Pagination from '../Common/Pagination';

const ContactList = () => {
  const [contacts, setContacts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [editingContact, setEditingContact] = useState(null);

  useEffect(() => {
    fetchContacts();
  }, [currentPage, search]);

  const fetchContacts = async () => {
    try {
      const response = await api.get(`/contacts?page=${currentPage}&search=${search}`);
      setContacts(response.data.contacts);
      setTotalPages(response.data.totalPages);
    } catch (err) {
      console.error('Error fetching contacts:', err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await api.delete(`/contacts/${id}`);
      fetchContacts();
    } catch (err) {
      console.error('Error deleting contact:', err);
    }
  };

  const handleEdit = (contact) => {
    setEditingContact(contact);
  };

  const handleFormSubmit = () => {
    setEditingContact(null);
    fetchContacts();
  };

  const handleSearch = (searchTerm) => {
    setSearch(searchTerm);
    setCurrentPage(1);
  };

  const handleImport = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('csv', file);
      try {
        await api.post('/contacts/import', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        fetchContacts();
      } catch (err) {
        console.error('Error importing contacts:', err);
      }
    }
  };

  const handleExport = async () => {
    try {
      const response = await api.get('/contacts/export', { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'contacts.csv');
      document.body.appendChild(link);
      link.click();
    } catch (err) {
      console.error('Error exporting contacts:', err);
    }
  };

  return (
    <div>
      <h2>Contacts</h2>
      <ContactSearch onSearch={handleSearch} />
      <ContactForm onSubmit={handleFormSubmit} editingContact={editingContact} />
      <div>
        <input type="file" accept=".csv" onChange={handleImport} />
        <button onClick={handleExport}>Export Contacts</button>
      </div>
      <ul>
        {contacts.map((contact) => (
          <li key={contact.id}>
            {contact.name} - {contact.email} - {contact.phone}
            <button onClick={() => handleEdit(contact)}>Edit</button>
            <button onClick={() => handleDelete(contact.id)}>Delete</button>
          </li>
        ))}
      </ul>
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
    </div>
  );
};

export default ContactList;

