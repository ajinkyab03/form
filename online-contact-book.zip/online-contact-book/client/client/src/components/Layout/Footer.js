// import React from 'react';
// import './Layout.css';

// const Footer = () => {
//   return (
//     <footer className="app-footer">
//       <p>&copy; 2024 Online Contact Book. All rights reserved.</p>
//     </footer>
//   );
// };

// export default Footer;

import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-4 text-center">
      <p className="text-sm">&copy; 2024 Online Contact Book. All rights reserved.</p>
      <div className="mt-2">
        <a href="/privacy" className="text-blue-400 hover:underline mx-2">Privacy Policy</a>
        <a href="/terms" className="text-blue-400 hover:underline mx-2">Terms of Service</a>
      </div>
    </footer>
  );
};

export default Footer;
