// import React from 'react';
// import { Link, useNavigate, useLocation } from 'react-router-dom';
// import './Layout.css';

// const Header = () => {
//   const navigate = useNavigate();
//   const location = useLocation();

//   const handleLogout = () => {
//     localStorage.removeItem('token');
//     navigate('/login');
//   };

//   const isLoggedIn = localStorage.getItem('token');

//   return (
//     <header className="app-header">
//       <div className="header-content">
//         <h1 className="app-title">Online Contact Book</h1>
//         <nav>
//           {isLoggedIn ? (
//             <>
//               <Link to="/contacts" className="nav-link">Contacts</Link>
//               <button onClick={handleLogout} className="btn btn-logout">Logout</button>
//             </>
//           ) : (
//             <>
//               {location.pathname !== '/login' && (
//                 <Link to="/login" className="nav-link">Login</Link>
//               )}
//               {location.pathname !== '/register' && (
//                 <Link to="/register" className="nav-link">Register</Link>
//               )}
//             </>
//           )}
//         </nav>
//       </div>
//     </header>
//   );
// };

// export default Header;

import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  const isLoggedIn = localStorage.getItem('token');

  return (
    <header className="bg-blue-600 text-white py-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center px-4">
        <h1 className="text-2xl font-semibold">Online Contact Book</h1>
        <nav className="space-x-4">
          {isLoggedIn ? (
            <>
              <Link to="/contacts" className="text-white hover:text-blue-200">Contacts</Link>
              <button
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              {location.pathname !== '/login' && (
                <Link to="/login" className="text-white hover:text-blue-200">Login</Link>
              )}
              {location.pathname !== '/register' && (
                <Link to="/register" className="text-white hover:text-blue-200">Register</Link>
              )}
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
