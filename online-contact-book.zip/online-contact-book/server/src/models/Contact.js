const db = require('../config/database');

class Contact {
  static async findAll(userId, page, limit, search) {
    const offset = (page - 1) * limit;
    let query = 'SELECT * FROM contacts WHERE user_id = ?';
    let countQuery = 'SELECT COUNT(*) as total FROM contacts WHERE user_id = ?';
    let params = [userId];

    if (search) {
      query += ' AND (name LIKE ? OR email LIKE ?)';
      countQuery += ' AND (name LIKE ? OR email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY name LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [contacts] = await db.query(query, params);
    const [countResult] = await db.query(countQuery, params.slice(0, -2));

    return {
      contacts,
      total: countResult[0].total
    };
  }

  static async findById(id, userId) {
    const [rows] = await db.query('SELECT * FROM contacts WHERE id = ? AND user_id = ?', [id, userId]);
    return rows[0];
  }

  static async create(userId, name, phone, email, address) {
    const [result] = await db.query(
      'INSERT INTO contacts (user_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)',
      [userId, name, phone, email, address]
    );
    return result.insertId;
  }

  static async update(id, userId, name, phone, email, address) {
    const [result] = await db.query(
      'UPDATE contacts SET name = ?, phone = ?, email = ?, address = ? WHERE id = ? AND user_id = ?',
      [name, phone, email, address, id, userId]
    );
    return result.affectedRows;
  }

  static async delete(id, userId) {
    const [result] = await db.query('DELETE FROM contacts WHERE id = ? AND user_id = ?', [id, userId]);
    return result.affectedRows;
  }
}

module.exports = Contact;