const db = require('../config/database');
const { parse } = require('csv-parse/sync');
const { stringify } = require('csv-stringify/sync');

exports.getContacts = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const search = req.query.search || '';

  try {
    let query = 'SELECT * FROM contacts WHERE user_id = ?';
    let countQuery = 'SELECT COUNT(*) as total FROM contacts WHERE user_id = ?';
    let params = [req.user.id];

    if (search) {
      query += ' AND (name LIKE ? OR email LIKE ?)';
      countQuery += ' AND (name LIKE ? OR email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY name LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [contacts] = await db.query(query, params);
    const [countResult] = await db.query(countQuery, params.slice(0, -2));

    const totalContacts = countResult[0].total;
    const totalPages = Math.ceil(totalContacts / limit);

    res.json({
      contacts,
      currentPage: page,
      totalPages,
      totalContacts
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.getContact = async (req, res) => {
  try {
    const [contact] = await db.query('SELECT * FROM contacts WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (contact.length === 0) {
      return res.status(404).json({ message: 'Contact not found' });
    }
    res.json(contact[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.createContact = async (req, res) => {
  const { name, phone, email, address } = req.body;

  try {
    const [result] = await db.query(
      'INSERT INTO contacts (user_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, name, phone, email, address]
    );
    res.status(201).json({ id: result.insertId, name, phone, email, address });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.updateContact = async (req, res) => {
  const { name, phone, email, address } = req.body;

  try {
    const [result] = await db.query(
      'UPDATE contacts SET name = ?, phone = ?, email = ?, address = ? WHERE id = ? AND user_id = ?',
      [name, phone, email, address, req.params.id, req.user.id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Contact not found' });
    }
    res.json({ id: req.params.id, name, phone, email, address });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.deleteContact = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM contacts WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Contact not found' });
    }
    res.json({ message: 'Contact removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.importContacts = async (req, res) => {
  if (!req.files || !req.files.csv) {
    return res.status(400).json({ message: 'No CSV file uploaded' });
  }

  try {
    const csvData = req.files.csv.data.toString('utf8');
    const records = parse(csvData, { columns: true, skip_empty_lines: true });

    for (const record of records) {
      await db.query(
        'INSERT INTO contacts (user_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)',
        [req.user.id, record.name, record.phone, record.email, record.address]
      );
    }

    res.json({ message: `${records.length} contacts imported successfully` });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.exportContacts = async (req, res) => {
  try {
    const [contacts] = await db.query('SELECT name, phone, email, address FROM contacts WHERE user_id = ?', [req.user.id]);
    const csvString = stringify(contacts, { header: true });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=contacts.csv');
    res.send(csvString);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};